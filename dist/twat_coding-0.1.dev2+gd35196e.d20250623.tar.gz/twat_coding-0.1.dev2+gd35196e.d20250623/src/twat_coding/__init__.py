"""twat-coding package."""

from twat_coding._version import __version__, version, version_tuple # Corrected import path

__all__ = ["__version__", "version", "version_tuple"]
