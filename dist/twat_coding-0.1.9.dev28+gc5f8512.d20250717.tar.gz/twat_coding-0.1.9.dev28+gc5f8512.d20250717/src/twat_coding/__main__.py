"""Main entry point for twat-coding CLI."""
# this_file: src/twat_coding/__main__.py

import sys
from twat_coding.pystubnik.cli import main

if __name__ == "__main__":
    sys.exit(main())