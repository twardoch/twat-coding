"""twat-coding package."""

from ._version import __version__, version, version_tuple

__all__ = ["__version__", "version", "version_tuple"]
