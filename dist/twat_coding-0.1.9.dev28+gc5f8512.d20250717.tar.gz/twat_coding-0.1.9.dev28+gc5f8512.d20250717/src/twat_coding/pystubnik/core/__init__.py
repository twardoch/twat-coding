"""Core components for pystubnik.

This package contains the core data structures, configuration models,
and utility functions used throughout the pystubnik library.
"""
