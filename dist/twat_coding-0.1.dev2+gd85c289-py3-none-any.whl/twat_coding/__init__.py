"""twat-coding package."""

from twat_coding.__version__ import __version__, version, version_tuple

__all__ = ["__version__", "version", "version_tuple"]
